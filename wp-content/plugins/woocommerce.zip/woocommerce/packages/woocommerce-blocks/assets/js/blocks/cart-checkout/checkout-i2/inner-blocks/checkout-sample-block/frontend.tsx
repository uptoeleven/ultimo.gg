/**
 * Internal dependencies
 */
import Block from './block';

const FrontendBlock = (): JSX.Element => {
	return <Block />;
};

export default FrontendBlock;
